//  1 уровень сложности: 1. Составьте программу, которая выводит на экран все однозначные положительные числа в возрастающем порядке.
// Перед началом вывода на экран следует вывести "старт", а после окончания вывода чисел – "финиш".
// вывод: старт, 1, … 9, финиш)

for(i=0;i<10;i++){
    if(i==0){
        console.log('старт');
    }
    console.log(i);
    if(i==9){
        console.log('финиш');
    }
}


// Составьте программу, которая выводит на экран все двузначные положительные числа, делящиеся без остатка на 3 и на 5 
// (начиная с наименьшего).
for(i=10;i<=99;i++){
    if(i%3==0){
    console.log(i);
}else if(i%5==0){
    console.log(i); 
}
}

//Подсчитать сумму всех чисел в заданном пользователем диапазоне.
function checkForNan(n1){
    while(isNaN(n1)){
        if (isNaN(n1)) {
            n1=+prompt('Enter the number');
        }else {
            break;
        }
        }
}
let numMin;
let numMax;
checkForNan(numMin =+prompt('Range start value'));
checkForNan(numMax=+prompt('Final range value'));
    let sum = 0;
    if(numMin<numMax){
    for(i=numMin;i<=numMax;i++){
        sum+=i;
        console.log(sum);
    }
    }else if(numMax<numMin){
        for(i=numMax;i<=numMin;i++){
            sum+=i;
            console.log(sum);  
        }
    }else if(numMin==numMax){
        console.log('Enter different numbers');
    }




//Запросить у пользователя число и вывести все делители этого числа.

let numb = +prompt('Еnter the number');
let a = [numb];
 if (numb%10==0) {
     a.unshift(10);  
}
 if(numb%5==0){
    a.unshift(5);
}
 if (numb%3==0) {
    a.unshift(3);
}
 if(numb%2==0){
    a.unshift(2);
}
a.unshift(1);
console.log(a);



//Запросить у пользователя 10 чисел и подсчитать, сколько он ввел положительных, отрицательных и нулей. При этом также посчитать, сколько четных и нечетных. Вывести статистику на экран. Учтите, что достаточно одной переменной (не 10) для ввода чисел пользователем.
let neg=0;
let poz=0;
let nul=0;
let honest=0;
let odd=0;

for(let n=0;n<=10;n++){
let number = +prompt('Еnter the number');
if(number<0){
neg+=1;
}
if(number>0){
poz+=1;
}
if(number!=0){
if (number%2==0) {
    honest+=1;  
}else {
    odd+=1;
}
}else if(number==0){
    nul+=1;   
}
}
console.log(`Из введеных чисел было ${neg} негативных, ${poz} позитивных и ${nul} раза ноль. А также ${honest} парных и ${odd} непарных.`)
