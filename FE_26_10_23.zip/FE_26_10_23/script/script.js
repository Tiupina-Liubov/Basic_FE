// 1 уровень сложности: LEVEL 1


// Написать программу, которая формирует на основе массива строк множество параграфов и выводит их в интерфейс. При клике на параграф текст должен меняться на звездочки. На данном этапе делать процесс обратимым при повторном клике необязательно.
let strings=['1','22','333','44444','55555','6666666','77777777','88888888','99999999999','10101010101010101010'];
for(let i=0;i<strings.length;i++){
    let paragraf = document.createElement('p')
    paragraf.innerText=strings[i];
    document.body.append(paragraf);
}
let list=document.querySelectorAll('p')
for(let paragraf of list){
paragraf.addEventListener('click',stars);

function stars(){
    paragraf.textContent = "*".repeat(paragraf.textContent.length);

 }  
}
// Реализовать 10 карточек с числами от 0 до 9 и при нажатии на какую-либо карточку присвоить ей класс active. В классе active должны быть стили, которые меняют цвет текста и цвет заднего фона местами.
for (let i = 0; i<10;i++){
    let div = document.createElement('div');
    div.innerText=i;

    document.body.append(div);

}
let divs=document.querySelectorAll('div');
for (let div of divs){
    div.addEventListener('click',newClass);

function newClass(){
    div.classList.toggle('active');
}
}
// Доработать прошлый скрипт таким образом, чтобы при повторном нажатии класс active удалялся.

// В JS объявлен массив с ссылками на картинки. На основе этого массива формируется множество маленьких картинок в верхней части интерфейса. При нажатии на одну из картинок забирается ссылка на эту картинку и в нижней части интерфейса отображается в большем размере. Так, пользователь, нажимая на маленькие картинки видит их отображение в большем размере.
 let pictures=['https://s00.yaplakal.com/pics/pics_preview/7/4/6/17827647.jpg','https://s00.yaplakal.com/pics/pics_preview/5/4/6/17827645.jpg','https://s00.yaplakal.com/pics/pics_preview/0/2/6/17827620.jpg', 'https://s00.yaplakal.com/pics/pics_preview/9/1/6/17827619.jpg','https://s00.yaplakal.com/pics/pics_preview/8/1/6/17827618.jpg']
let divImg=document.createElement('div');
divImg.setAttribute('id','imagesDiv');
document.body.append(divImg);
for(let i=0;i<pictures.length;i++){
       let tegA=document.createElement('a');
        tegA.setAttribute('src',pictures[i], );
        let tegImg = document.createElement('img');
        tegImg.classList='smoll';
       tegImg.setAttribute('src',pictures[i]);
       document.body>divImg>tegA.append(tegImg);
        document.body>divImg.append(tegA);
}
     let imgTegs=document.querySelectorAll('.smoll');
     for(let imgTeg of imgTegs){
      imgTeg.addEventListener('click', bigFormat);

     function bigFormat(){

      imgTeg.style.height='60%';
      imgTeg.style.width ='80%'
      imgTeg.classList.replace('smoll','big');
      document.body>divImg.after(imgTeg);
      
     }
     }
     let imgBody=document.querySelectorAll('.big');
     for(let img of imgBody){
      img.addEventListener('click', smollFormat);

      function smollFormat(){
        img.classList.replace('big','smoll')

      
      
      }
    }

// LEVEL 2

// Есть массив из объектов. Каждый объект имеет свойства en и ru. В свойстве en написано слово на английском, а в свойстве ru на русском. Необходимо реализовать карточки, при нажатии на которые слова с русского меняются на английский и обратно.
// Подсказка. В каждой карточке должно быть два параграфа. В одном написано на русском, а во втором на английском и при нажатии на карточку один параграф получает класс с display none а второй с display block.
let obeckts=[
    {eng:'Lena',rus:'Лена'},
    {eng:'Peter',rus:'Петер'},
    {eng:'Ruslan',rus:'Руслан'},   
]
for(let i=0;i<obeckts.length;i++){
    let div = document.createElement('div');
    div.classList.add('eng');
    let paragEng = document.createElement('p');
        paragEng.innerText=obeckts[i].eng;
    div.prepend(paragEng);
    let paragRus= document.createElement('p');
    div.prepend(paragRus);
    paragRus.innerText=obeckts[i].rus;
    paragRus.classList.add('none')
       document.body.append(div)
       div.addEventListener('click',switchLanguage);
       function switchLanguage(){
        paragEng.classList.toggle('none');
        paragRus.classList.toggle('none');
       }
}






// Добавить внизу кнопки RU и EN при нажатии на которые все карточки переключаются на русский или английский соответственно.

// Написать цикл, который создает множество div-ов c цветами от rgb(128, 128, 0) до rgb(128, 128, 255). У дивов цвет должен меняться с шагом 5
//

for(let i =0; i<255;i+=5){
  let divColor = document.createElement('div');
  let b= [128, 128, i];
  divColor.classList.add='color';
  divColor.style.height='10px';
  divColor.style.margin='0';
  divColor.style.border= '1px solid '+'rgb('+b+')';
  document.body.after(divColor);
   
   divColor.style.backgroundColor='rgb('+b+')';



   } 
